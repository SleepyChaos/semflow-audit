'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-13a4654b8a/Case39e596f39ddf', methods=['GET'])
	def Case39e596f39ddf_get():
		response = make_response(render_template('web/group-13a4654b8a/Case39e596f39ddf.html'))
		response.set_cookie('Case39e596f39ddf', 'name%3A+safe+data%0Atext%3A+act+like+this+is+conf+data',
			max_age=60*3,
			secure=True,
			path=request.path,
			domain='localhost')
		return response
		return Case39e596f39ddf_post()

	@app.route('/benchmark/group-13a4654b8a/Case39e596f39ddf', methods=['POST'])
	def Case39e596f39ddf_post():
		RESPONSE = ""

		import urllib.parse
		param = urllib.parse.unquote_plus(request.cookies.get("Case39e596f39ddf", "noCookieValueSupplied"))

		bar = param

		import yaml

		try:
			yobj = yaml.safe_load(bar)

			RESPONSE += (
				yobj['text']
			)
		except:
			RESPONSE += (
				"There was an error loading the configuration"
			)

		return RESPONSE

