'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-d446939451/Case22fa8a05f853', methods=['GET'])
	def Case22fa8a05f853_get():
		return Case22fa8a05f853_post()

	@app.route('/benchmark/group-d446939451/Case22fa8a05f853', methods=['POST'])
	def Case22fa8a05f853_post():
		RESPONSE = ""

		param = ""
		for name in request.form.keys():
			if "Case22fa8a05f853" in request.form.getlist(name):
				param = name
				break

		bar = ""
		if param:
			lst = []
			lst.append('safe')
			lst.append(param)
			lst.append('moresafe')
			lst.pop(0)
			bar = lst[0]

		import random
		from helpers.utils import mysession

		num = 'Case22fa8a05f853'[13:]
		user = f'Randy{num}'
		cookie = f'rememberMe{num}'
		value = str(random.getrandbits(32))

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie: '
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

