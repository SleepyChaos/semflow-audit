'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-24f89a27b3/Case1d6363118cb7', methods=['GET'])
	def Case1d6363118cb7_get():
		response = make_response(render_template('web/group-24f89a27b3/Case1d6363118cb7.html'))
		response.set_cookie('Case1d6363118cb7', 'whatever',
			max_age=60*3,
			secure=True,
			path=request.path,
			domain='localhost')
		return response
		return Case1d6363118cb7_post()

	@app.route('/benchmark/group-24f89a27b3/Case1d6363118cb7', methods=['POST'])
	def Case1d6363118cb7_post():
		RESPONSE = ""

		import urllib.parse
		param = urllib.parse.unquote_plus(request.cookies.get("Case1d6363118cb7", "noCookieValueSupplied"))

		string47148 = 'help'
		string47148 += param
		string47148 += 'snapes on a plane'
		bar = string47148[4:-17]

		import base64
		import secrets
		from helpers.utils import mysession

		num = 'Case1d6363118cb7'[13:]
		user = f'SafeToby{num}'
		cookie = f'rememberMe{num}'
		value = base64.b64encode(secrets.token_bytes(32))

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie:'
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

