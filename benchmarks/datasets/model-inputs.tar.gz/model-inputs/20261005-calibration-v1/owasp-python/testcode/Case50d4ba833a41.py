'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-5c169573b9/Case50d4ba833a41', methods=['GET'])
	def Case50d4ba833a41_get():
		return Case50d4ba833a41_post()

	@app.route('/benchmark/group-5c169573b9/Case50d4ba833a41', methods=['POST'])
	def Case50d4ba833a41_post():
		RESPONSE = ""

		import urllib.parse
		
		query_string = request.query_string.decode('utf-8')
		paramLoc = query_string.find("Case50d4ba833a41" + '=')
		if paramLoc == -1:
			return f"request.query_string did not contain expected parameter \'{"Case50d4ba833a41"}\'."
		param = query_string[paramLoc + len("Case50d4ba833a41") + 1:]
		ampLoc = param.find('&')
		if ampLoc != -1:
			param = param[:ampLoc]
		
		param = urllib.parse.unquote_plus(param)

		map36088 = {}
		map36088['keyA-36088'] = 'a-Value'
		map36088['keyB-36088'] = param
		map36088['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map36088['keyB-36088']
		bar = map36088['keyA-36088']

		import secrets
		from helpers.utils import mysession

		num = 'Case50d4ba833a41'[13:]
		user = f'SafeRicky{num}'
		cookie = f'rememberMe{num}'
		value = str(secrets.randbits(32))

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie:'
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

