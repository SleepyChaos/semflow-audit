'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-13a4654b8a/Case10bfc955cb7f', methods=['GET'])
	def Case10bfc955cb7f_get():
		return Case10bfc955cb7f_post()

	@app.route('/benchmark/group-13a4654b8a/Case10bfc955cb7f', methods=['POST'])
	def Case10bfc955cb7f_post():
		RESPONSE = ""

		import urllib.parse
		
		query_string = request.query_string.decode('utf-8')
		paramLoc = query_string.find("Case10bfc955cb7f" + '=')
		if paramLoc == -1:
			return f"request.query_string did not contain expected parameter \'{"Case10bfc955cb7f"}\'."
		param = query_string[paramLoc + len("Case10bfc955cb7f") + 1:]
		ampLoc = param.find('&')
		if ampLoc != -1:
			param = param[:ampLoc]
		
		param = urllib.parse.unquote_plus(param)

		map95803 = {}
		map95803['keyA-95803'] = 'a-Value'
		map95803['keyB-95803'] = param
		map95803['keyC'] = 'another-Value'
		bar = map95803['keyB-95803']

		import yaml

		try:
			yobj = yaml.load(bar, Loader=yaml.Loader)

			RESPONSE += (
				yobj['text']
			)
		except:
			RESPONSE += (
				"There was an error loading the configuration"
			)

		return RESPONSE

