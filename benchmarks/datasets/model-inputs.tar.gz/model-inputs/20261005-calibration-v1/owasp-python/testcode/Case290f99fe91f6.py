'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-6eac7893ad/Case290f99fe91f6', methods=['GET'])
	def Case290f99fe91f6_get():
		return Case290f99fe91f6_post()

	@app.route('/benchmark/group-6eac7893ad/Case290f99fe91f6', methods=['POST'])
	def Case290f99fe91f6_post():
		RESPONSE = ""

		param = request.headers.get("Case290f99fe91f6")
		if not param:
		    param = ""

		map37779 = {}
		map37779['keyA-37779'] = 'a-Value'
		map37779['keyB-37779'] = param
		map37779['keyC'] = 'another-Value'
		bar = map37779['keyB-37779']

		import flask

		flask.session[bar] = '12345'

		RESPONSE += (
			f'Item: \'{escape_for_html(bar)}'
			'\' with value: 12345 saved in session.'
		)

		return RESPONSE

