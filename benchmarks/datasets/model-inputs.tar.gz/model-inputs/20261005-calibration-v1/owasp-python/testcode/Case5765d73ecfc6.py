'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-b18bcbdbf7/Case5765d73ecfc6', methods=['GET'])
	def Case5765d73ecfc6_get():
		return Case5765d73ecfc6_post()

	@app.route('/benchmark/group-b18bcbdbf7/Case5765d73ecfc6', methods=['POST'])
	def Case5765d73ecfc6_post():
		RESPONSE = ""

		import helpers.separate_request
		
		wrapped = helpers.separate_request.request_wrapper(request)
		param = wrapped.get_form_parameter("Case5765d73ecfc6")
		if not param:
			param = ""

		map78565 = {}
		map78565['keyA-78565'] = 'a-Value'
		map78565['keyB-78565'] = param
		map78565['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map78565['keyB-78565']
		bar = map78565['keyA-78565']

		try:
			exec(bar)
		except:
			RESPONSE += (
				f'Error executing statement \'{escape_for_html(bar)}\''
			)

		return RESPONSE

