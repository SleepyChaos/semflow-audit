'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-bfb403c7a7/Case2f908f1abe2c', methods=['GET'])
	def Case2f908f1abe2c_get():
		return Case2f908f1abe2c_post()

	@app.route('/benchmark/group-bfb403c7a7/Case2f908f1abe2c', methods=['POST'])
	def Case2f908f1abe2c_post():
		RESPONSE = ""

		import urllib.parse
		
		query_string = request.query_string.decode('utf-8')
		paramLoc = query_string.find("Case2f908f1abe2c" + '=')
		if paramLoc == -1:
			return f"request.query_string did not contain expected parameter \'{"Case2f908f1abe2c"}\'."
		param = query_string[paramLoc + len("Case2f908f1abe2c") + 1:]
		ampLoc = param.find('&')
		if ampLoc != -1:
			param = param[:ampLoc]
		
		param = urllib.parse.unquote_plus(param)

		import configparser
		
		bar = 'safe!'
		conf73877 = configparser.ConfigParser()
		conf73877.add_section('section73877')
		conf73877.set('section73877', 'keyA-73877', 'a-Value')
		conf73877.set('section73877', 'keyB-73877', param)
		bar = conf73877.get('section73877', 'keyB-73877')

		import pathlib
		import helpers.utils

		try:
			testfiles = pathlib.Path(helpers.utils.TESTFILES_DIR)
			p = testfiles / bar
			RESPONSE += (
				f'The beginning of file: \'{escape_for_html(str(p))}\' is:\n\n'
				f'{escape_for_html(p.read_text()[:1000])}'
			)
		except OSError:
			RESPONSE += (
				f'Problem reading from file \'{{escape_for_html(fileName)}}\': '
				f'{escape_for_html(e.strerror)}'
			)

		return RESPONSE

