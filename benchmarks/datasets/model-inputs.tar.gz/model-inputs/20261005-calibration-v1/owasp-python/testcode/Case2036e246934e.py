'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-96dcd5cfb1/Case2036e246934e', methods=['GET'])
	def Case2036e246934e_get():
		return Case2036e246934e_post()

	@app.route('/benchmark/group-96dcd5cfb1/Case2036e246934e', methods=['POST'])
	def Case2036e246934e_post():
		RESPONSE = ""

		param = request.args.get("Case2036e246934e")
		if not param:
			param = ""


		import flask
		import urllib.parse

		try:
			url = urllib.parse.urlparse(param)
			if url.netloc not in ['google.com'] or url.scheme != 'https':
				RESPONSE += (
					'Invalid URL.'
				)
				return RESPONSE
		except:
			RESPONSE += (
				'Error parsing URL.'
			)
			return RESPONSE

		return flask.redirect(param)

		return RESPONSE


