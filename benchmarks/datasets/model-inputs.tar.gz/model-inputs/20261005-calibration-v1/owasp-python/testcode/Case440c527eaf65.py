'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-4442da1d06/Case440c527eaf65', methods=['GET'])
	def Case440c527eaf65_get():
		return Case440c527eaf65_post()

	@app.route('/benchmark/group-4442da1d06/Case440c527eaf65', methods=['POST'])
	def Case440c527eaf65_post():
		RESPONSE = ""

		param = request.form.get("Case440c527eaf65")
		if not param:
			param = ""

		map15517 = {}
		map15517['keyA-15517'] = 'a-Value'
		map15517['keyB-15517'] = param
		map15517['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map15517['keyB-15517']
		bar = map15517['keyA-15517']


		RESPONSE += (
			f'Parameter value: {bar}'
		)

		return RESPONSE

