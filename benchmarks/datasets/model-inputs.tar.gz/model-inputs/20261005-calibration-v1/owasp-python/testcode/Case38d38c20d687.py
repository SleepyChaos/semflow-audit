'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-b9862de868/Case38d38c20d687', methods=['GET'])
	def Case38d38c20d687_get():
		return Case38d38c20d687_post()

	@app.route('/benchmark/group-b9862de868/Case38d38c20d687', methods=['POST'])
	def Case38d38c20d687_post():
		RESPONSE = ""

		param = request.headers.get("Case38d38c20d687")
		if not param:
		    param = ""

		map94841 = {}
		map94841['keyA-94841'] = 'a-Value'
		map94841['keyB-94841'] = param
		map94841['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map94841['keyB-94841']
		bar = map94841['keyA-94841']

		import elementpath
		import xml.etree.ElementTree as ET
		import helpers.utils

		try:
			root = ET.parse(f'{helpers.utils.RES_DIR}/employees.xml')
			query = f"/Employees/Employee[@emplid=\'{bar}\']"
			nodes = elementpath.select(root, query)
			node_strings = []
			for node in nodes:
				node_strings.append(' '.join([e.text for e in node]))

			RESPONSE += (
				f'Your XPATH query results are: <br>[ {', '.join(node_strings)} ]'
			)
		except:
			RESPONSE += (
				f'Error parsing XPath Query: \'{escape_for_html(query)}\''
			)

		return RESPONSE

