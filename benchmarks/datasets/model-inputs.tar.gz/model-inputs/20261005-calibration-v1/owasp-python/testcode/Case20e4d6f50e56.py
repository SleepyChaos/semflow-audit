'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-15232c0fe5/Case20e4d6f50e56', methods=['GET'])
	def Case20e4d6f50e56_get():
		return Case20e4d6f50e56_post()

	@app.route('/benchmark/group-15232c0fe5/Case20e4d6f50e56', methods=['POST'])
	def Case20e4d6f50e56_post():
		RESPONSE = ""

		param = request.args.get("Case20e4d6f50e56")
		if not param:
			param = ""

		map98877 = {}
		map98877['keyA-98877'] = 'a-Value'
		map98877['keyB-98877'] = param
		map98877['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map98877['keyB-98877']
		bar = map98877['keyA-98877']

		import lxml.etree
		import helpers.utils

		try:
			fd = open(f'{helpers.utils.RES_DIR}/employees.xml', 'rb')
			root = lxml.etree.parse(fd)
			query = f'/Employees/Employee[@emplid=$name]'
			nodes = root.xpath(query, name=bar)
			node_strings = []
			for node in nodes:
				node_strings.append(' '.join([e.text for e in node]))

			RESPONSE += (
				f'Your XPATH query results are: <br>[ {', '.join(node_strings)} ]'
			)
		except:
			RESPONSE += (
				f'Error parsing XPath Query: \'{escape_for_html(query)}\''
			)

		return RESPONSE

