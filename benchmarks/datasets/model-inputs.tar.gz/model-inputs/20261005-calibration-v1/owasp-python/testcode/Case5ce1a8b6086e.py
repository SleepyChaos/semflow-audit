'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-b9862de868/Case5ce1a8b6086e', methods=['GET'])
	def Case5ce1a8b6086e_get():
		return Case5ce1a8b6086e_post()

	@app.route('/benchmark/group-b9862de868/Case5ce1a8b6086e', methods=['POST'])
	def Case5ce1a8b6086e_post():
		RESPONSE = ""

		values = request.form.getlist("Case5ce1a8b6086e")
		param = ""
		if values:
			param = values[0]

		import configparser
		
		bar = 'safe!'
		conf72771 = configparser.ConfigParser()
		conf72771.add_section('section72771')
		conf72771.set('section72771', 'keyA-72771', 'a-Value')
		conf72771.set('section72771', 'keyB-72771', param)
		bar = conf72771.get('section72771', 'keyB-72771')

		import lxml.etree
		import helpers.utils
		import io

		try:
			fd = open(f'{helpers.utils.RES_DIR}/employees.xml', 'rb')
			root = lxml.etree.parse(fd)
			strIO = io.StringIO()
			strIO.write('/Employees/Employee[@emplid=\'')
			strIO.write(bar)
			strIO.write('\']')
			query = strIO.getvalue()

			nodes = root.xpath(query)
			node_strings = []
			for node in nodes:
				node_strings.append(' '.join([e.text for e in node]))

			RESPONSE += (
				f'Your XPATH query results are: <br>[ {', '.join(node_strings)} ]'
			)
		except:
			RESPONSE += (
				f'Error parsing XPath Query: \'{escape_for_html(query)}\''
			)

		return RESPONSE

