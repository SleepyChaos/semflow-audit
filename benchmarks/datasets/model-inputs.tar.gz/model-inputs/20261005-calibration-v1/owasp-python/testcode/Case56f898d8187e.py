'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-5c169573b9/Case56f898d8187e', methods=['GET'])
	def Case56f898d8187e_get():
		return Case56f898d8187e_post()

	@app.route('/benchmark/group-5c169573b9/Case56f898d8187e', methods=['POST'])
	def Case56f898d8187e_post():
		RESPONSE = ""

		parts = request.path.split("/")
		param = parts[1]
		if not param:
			param = ""

		map9561 = {}
		map9561['keyA-9561'] = 'a-Value'
		map9561['keyB-9561'] = param
		map9561['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map9561['keyB-9561']
		bar = map9561['keyA-9561']

		import random
		from helpers.utils import mysession

		num = 'Case56f898d8187e'[13:]
		user = f'Randall{num}'
		cookie = f'rememberMe{num}'
		value = str(random.random())[2:]

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie: '
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

