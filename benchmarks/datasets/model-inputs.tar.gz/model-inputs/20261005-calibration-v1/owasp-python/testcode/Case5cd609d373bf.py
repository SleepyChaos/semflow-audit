'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-9b7d6d044d/Case5cd609d373bf', methods=['GET'])
	def Case5cd609d373bf_get():
		return Case5cd609d373bf_post()

	@app.route('/benchmark/group-9b7d6d044d/Case5cd609d373bf', methods=['POST'])
	def Case5cd609d373bf_post():
		RESPONSE = ""

		param = request.args.get("Case5cd609d373bf")
		if not param:
			param = ""

		map47971 = {}
		map47971['keyA-47971'] = 'a-Value'
		map47971['keyB-47971'] = param
		map47971['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map47971['keyB-47971']
		bar = map47971['keyA-47971']

		import hashlib, base64
		import io, helpers.utils

		input = ''
		if isinstance(bar, str):
			input = bar.encode('utf-8')
		elif isinstance(bar, io.IOBase):
			input = bar.read(1000)

		if len(input) == 0:
			RESPONSE += (
				'Cannot generate hash: Input was empty.'
			)
			return RESPONSE

		hash = hashlib.new('md5')
		hash.update(input)

		result = hash.digest()
		f = open(f'{helpers.utils.TESTFILES_DIR}/passwordFile.txt', 'a')
		f.write(f'hash_value={base64.b64encode(result)}\n')
		RESPONSE += (
			f'Sensitive value \'{helpers.utils.escape_for_html(input.decode('utf-8'))}\' hashed and stored.'
		)
		f.close()

		return RESPONSE

