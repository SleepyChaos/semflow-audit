'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-4442da1d06/Case4adaa16f735a', methods=['GET'])
	def Case4adaa16f735a_get():
		return Case4adaa16f735a_post()

	@app.route('/benchmark/group-4442da1d06/Case4adaa16f735a', methods=['POST'])
	def Case4adaa16f735a_post():
		RESPONSE = ""

		param = ""
		headers = request.headers.getlist("Referer")
		
		if headers:
			param = headers[0]

		bar = "This should never happen"
		if 'should' in bar:
			bar = param


		otherarg = "static text"
		RESPONSE += (
			f'bar is \'{bar}\' and otherarg is \'{otherarg}\''
		)

		return RESPONSE

