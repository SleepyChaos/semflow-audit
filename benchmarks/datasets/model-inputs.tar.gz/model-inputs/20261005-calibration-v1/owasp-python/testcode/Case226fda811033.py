'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-4442da1d06/Case226fda811033', methods=['GET'])
	def Case226fda811033_get():
		return Case226fda811033_post()

	@app.route('/benchmark/group-4442da1d06/Case226fda811033', methods=['POST'])
	def Case226fda811033_post():
		RESPONSE = ""

		param = request.form.get("Case226fda811033")
		if not param:
			param = ""

		import configparser
		
		bar = 'safe!'
		conf43475 = configparser.ConfigParser()
		conf43475.add_section('section43475')
		conf43475.set('section43475', 'keyA-43475', 'a-Value')
		conf43475.set('section43475', 'keyB-43475', param)
		bar = conf43475.get('section43475', 'keyB-43475')


		dict = {}
		dict['bar'] = bar
		dict['otherarg'] = 'this is it'
		RESPONSE += (
			'bar is \'{0[bar]}\' and otherarg is \'{0[otherarg]}\''.format(dict)
		)

		return RESPONSE

