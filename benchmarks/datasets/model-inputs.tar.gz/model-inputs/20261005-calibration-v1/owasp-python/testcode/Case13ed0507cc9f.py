'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-13a4654b8a/Case13ed0507cc9f', methods=['GET'])
	def Case13ed0507cc9f_get():
		return Case13ed0507cc9f_post()

	@app.route('/benchmark/group-13a4654b8a/Case13ed0507cc9f', methods=['POST'])
	def Case13ed0507cc9f_post():
		RESPONSE = ""

		values = request.args.getlist("Case13ed0507cc9f")
		param = ""
		if values:
			param = values[0]

		bar = ''
		if param:
			bar = param.split(' ')[0]

		import yaml

		try:
			yobj = yaml.safe_load(bar)

			RESPONSE += (
				yobj['text']
			)
		except:
			RESPONSE += (
				"There was an error loading the configuration"
			)

		return RESPONSE

