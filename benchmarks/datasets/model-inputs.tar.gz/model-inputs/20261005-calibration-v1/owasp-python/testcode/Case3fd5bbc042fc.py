'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-b18bcbdbf7/Case3fd5bbc042fc', methods=['GET'])
	def Case3fd5bbc042fc_get():
		return Case3fd5bbc042fc_post()

	@app.route('/benchmark/group-b18bcbdbf7/Case3fd5bbc042fc', methods=['POST'])
	def Case3fd5bbc042fc_post():
		RESPONSE = ""

		import helpers.separate_request
		
		wrapped = helpers.separate_request.request_wrapper(request)
		param = wrapped.get_form_parameter("Case3fd5bbc042fc")
		if not param:
			param = ""

		map7018 = {}
		map7018['keyA-7018'] = 'a-Value'
		map7018['keyB-7018'] = param
		map7018['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map7018['keyB-7018']
		bar = map7018['keyA-7018']

		if not bar.startswith('\'') or not bar.endswith('\'') or '\'' in bar[1:-1]:
			RESPONSE += (
				"Eval argument must be a plain string literal."
			)
			return RESPONSE		

		try:
			RESPONSE += (
				eval(bar)
			)
		except:
			RESPONSE += (
				f'Error evaluating expression \'{escape_for_html(bar)}\''
			)

		return RESPONSE

