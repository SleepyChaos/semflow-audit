'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-9b7d6d044d/Case29e315a9da8b', methods=['GET'])
	def Case29e315a9da8b_get():
		return Case29e315a9da8b_post()

	@app.route('/benchmark/group-9b7d6d044d/Case29e315a9da8b', methods=['POST'])
	def Case29e315a9da8b_post():
		RESPONSE = ""

		param = request.form.get("Case29e315a9da8b")
		if not param:
			param = ""


		import hashlib, base64
		import io, helpers.utils

		input = ''
		if isinstance(param, str):
			input = param.encode('utf-8')
		elif isinstance(param, io.IOBase):
			input = param.read(1000)

		if len(input) == 0:
			RESPONSE += (
				'Cannot generate hash: Input was empty.'
			)
			return RESPONSE

		hash = hashlib.md5()
		hash.update(input)

		result = hash.digest()
		f = open(f'{helpers.utils.TESTFILES_DIR}/passwordFile.txt', 'a')
		f.write(f'hash_value={base64.b64encode(result)}\n')
		RESPONSE += (
			f'Sensitive value \'{helpers.utils.escape_for_html(input.decode('utf-8'))}\' hashed and stored.'
		)
		f.close()

		return RESPONSE


