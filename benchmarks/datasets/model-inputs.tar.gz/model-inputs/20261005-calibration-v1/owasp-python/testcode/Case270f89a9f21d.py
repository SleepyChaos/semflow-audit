'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-6eac7893ad/Case270f89a9f21d', methods=['GET'])
	def Case270f89a9f21d_get():
		return Case270f89a9f21d_post()

	@app.route('/benchmark/group-6eac7893ad/Case270f89a9f21d', methods=['POST'])
	def Case270f89a9f21d_post():
		RESPONSE = ""

		param = request.form.get("Case270f89a9f21d")
		if not param:
			param = ""

		import configparser
		
		bar = 'safe!'
		conf13396 = configparser.ConfigParser()
		conf13396.add_section('section13396')
		conf13396.set('section13396', 'keyA-13396', 'a_Value')
		conf13396.set('section13396', 'keyB-13396', param)
		bar = conf13396.get('section13396', 'keyA-13396')

		import flask

		flask.session[bar] = '12345'

		RESPONSE += (
			f'Item: \'{escape_for_html(bar)}'
			'\' with value: 12345 saved in session.'
		)

		return RESPONSE

