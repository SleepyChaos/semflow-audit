'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-d446939451/Case54d94b13c2a6', methods=['GET'])
	def Case54d94b13c2a6_get():
		return Case54d94b13c2a6_post()

	@app.route('/benchmark/group-d446939451/Case54d94b13c2a6', methods=['POST'])
	def Case54d94b13c2a6_post():
		RESPONSE = ""

		import helpers.separate_request
		
		wrapped = helpers.separate_request.request_wrapper(request)
		param = wrapped.get_form_parameter("Case54d94b13c2a6")
		if not param:
			param = ""

		map12849 = {}
		map12849['keyA-12849'] = 'a-Value'
		map12849['keyB-12849'] = param
		map12849['keyC'] = 'another-Value'
		bar = "safe!"
		bar = map12849['keyB-12849']
		bar = map12849['keyA-12849']

		import random
		from helpers.utils import mysession

		num = 'Case54d94b13c2a6'[13:]
		user = f'SafeIsaac{num}'
		cookie = f'rememberMe{num}'
		value = str(random.SystemRandom().randint(0, 2**32))

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie: '
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

