'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-d446939451/Case3a5bf0b4a7ce', methods=['GET'])
	def Case3a5bf0b4a7ce_get():
		return Case3a5bf0b4a7ce_post()

	@app.route('/benchmark/group-d446939451/Case3a5bf0b4a7ce', methods=['POST'])
	def Case3a5bf0b4a7ce_post():
		RESPONSE = ""

		param = request.headers.get("Case3a5bf0b4a7ce")
		if not param:
		    param = ""

		bar = param

		import base64
		import secrets
		from helpers.utils import mysession

		num = 'Case3a5bf0b4a7ce'[13:]
		user = f'SafeTruman{num}'
		cookie = f'rememberMe{num}'
		value = secrets.token_urlsafe(32)

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie:'
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

