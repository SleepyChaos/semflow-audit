'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-d446939451/Case0b6cbf1405cf', methods=['GET'])
	def Case0b6cbf1405cf_get():
		return Case0b6cbf1405cf_post()

	@app.route('/benchmark/group-d446939451/Case0b6cbf1405cf', methods=['POST'])
	def Case0b6cbf1405cf_post():
		RESPONSE = ""

		values = request.form.getlist("Case0b6cbf1405cf")
		param = ""
		if values:
			param = values[0]

		string30318 = ''
		data12 = ''
		copy = string30318
		string30318 = ''
		string30318 += param
		copy += 'SomeOKString'
		bar = copy

		import random
		from helpers.utils import mysession

		num = 'Case0b6cbf1405cf'[13:]
		user = f'SafeIsaac{num}'
		cookie = f'rememberMe{num}'
		value = str(random.SystemRandom().randint(0, 2**32))

		if cookie in mysession and request.cookies.get(cookie) == mysession[cookie]:
			RESPONSE += (
				f'Welcome back: {user}<br/>'
			)
		else:
			mysession[cookie] = value
			RESPONSE += (
				f'{user} has been remembered with cookie: '
				f'{cookie} whose value is: {mysession[cookie]}<br/>'
			)

		return RESPONSE

