'''
OWASP Benchmark for Python v0.1

This file is part of the Open Web Application Security Project (OWASP) Benchmark Project.
For details, please see https://owasp.org/www-project-benchmark.

The OWASP Benchmark is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, version 3.

The OWASP Benchmark is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License for more details.

  Author: Theo Cartsonis
  Created: 2025
'''

from flask import redirect, url_for, request, make_response, render_template
from helpers.utils import escape_for_html

def init(app):

	@app.route('/benchmark/group-e3878254df/Case1143a063f5a7', methods=['GET'])
	def Case1143a063f5a7_get():
		response = make_response(render_template('web/group-e3878254df/Case1143a063f5a7.html'))
		response.set_cookie('Case1143a063f5a7', 'FileName',
			max_age=60*3,
			secure=True,
			path=request.path,
			domain='localhost')
		return response
		return Case1143a063f5a7_post()

	@app.route('/benchmark/group-e3878254df/Case1143a063f5a7', methods=['POST'])
	def Case1143a063f5a7_post():
		RESPONSE = ""

		import urllib.parse
		param = urllib.parse.unquote_plus(request.cookies.get("Case1143a063f5a7", "noCookieValueSupplied"))

		map44013 = {}
		map44013['keyA-44013'] = 'a-Value'
		map44013['keyB-44013'] = param
		map44013['keyC'] = 'another-Value'
		bar = map44013['keyB-44013']

		import helpers.utils

		fileName = None
		fd = None

		if '../' in bar:
			RESPONSE += (
				'File name must not include \'../\''
			)
			return RESPONSE

		try:
			fileName = f'{helpers.utils.TESTFILES_DIR}/{bar}'
			fd = open(fileName, 'rb')
			RESPONSE += (
				f'The beginning of file: \'{escape_for_html(fileName)}\' is:\n\n'
				f'{escape_for_html(fd.read(1000).decode('utf-8'))}'
			)
		except IOError as e:
			RESPONSE += (
				f'Problem reading from file \'{{escape_for_html(fileName)}}\': '
				f'{escape_for_html(e.strerror)}'
			)
		finally:
			try:
				if fd is not None:
					fd.close()
			except IOError:
				pass # "// we tried..."

		return RESPONSE

