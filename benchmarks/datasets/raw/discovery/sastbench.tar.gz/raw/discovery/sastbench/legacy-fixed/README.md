<p align="center">
<img src="assets/sastbench_logo.png" width="400px"/>
</p>

<p align="center">
  <a href="https://arxiv.org/abs/2601.02941"><img src="https://img.shields.io/badge/arXiv-2601.02941-red" alt="Arxiv Link"/></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-Apache_2.0-fbb040" alt="License"/></a>
  <a href="https://rival.security/"><img src="https://img.shields.io/badge/Rival-Research-gray?labelColor=44bb44" alt="License"/>
  </a>
  <br/>
  <br/>
</p>

**Benchmark and evaluation framework for static application security testing (SAST) and vulnerability analysis agents.**

<br/>


**SastBench** ([Feiglin and Dar, 2026](https://arxiv.org/abs/2601.02941)) is a framework for evaluating automated **SAST** (Static Application Security Testing) triage agents. It provides a benchmark to help advance agents that can analyze security tool findings, assist with the **triage process** (i.e., identifying true and false positive vulnerability reports), and support secure development workflows. 




**Created with &nbsp;❤️&nbsp; by [Rival Security](https://rival.security/).**
## Layout

- **`evaluation/`** — CLI and runner: run evaluations, manage workers, produce reports.
- **`agents/`** — Analyzer implementations: `simple_react_agent`, `oneshot_analyzer`, `mini_sweagent_agent`. Each exposes a Dockerized REST API used by the evaluator.
- **`data/`** — Benchmark dataset (e.g. `sastbench-v0.1-jan2024-jun2024.json`).
- **`dataset_generation/`** — CVE SQLite from NVD + PyDriller (`build-cve-db`), then SastBench JSON; run **`python -m dataset_generation.cli build-benchmark …`** for the full pipeline. Optional **`.env`** for `GITHUB_TOKEN` (`dataset_generation/env.example`). See **`dataset_generation/README.md`**.

## Dataset structure

The benchmark data is a **JSON array** of findings. Each element must have:

| Field          | Required | Description |
|----------------|----------|-------------|
| `finding_id`   | Yes      | Unique identifier for this finding (e.g. `commit_hash:CWE-id:ground_truth`). |
| `repo_url`     | Yes      | Git repository URL. |
| `commit_hash`  | Yes      | Full commit SHA to evaluate. |
| `ground_truth` | Yes      | `"true_positive"` or `"false_positive"`. |
| `metadata`     | No       | Arbitrary metadata (e.g. `cwe_id`, `source`, `aggregation_type`); used in reports. |
| `to_analyzer`  | Yes      | Payload sent to the agent’s `/analyze` endpoint (see below). |

The evaluator groups findings by `(repo_url, commit_hash)`, checks out that commit, runs **preprocess** once per commit, then calls **analyze** once per finding, passing `finding["to_analyzer"]` as `finding_data`. The agent must return a prediction (`true_positive` / `false_positive` / `error`) and a confidence (confidence is saved in the logs, but it usually isn't very useful -- it can be set to a constant value); correctness is computed against `ground_truth`.

**`to_analyzer`** is intentionally generic: it can be any JSON object your agent understands. The bundled dataset uses a shape like:

- `vulnerability_type`, `vulnerability_name`, `description` — CWE and description.
- `locations` — Array of `{ file, function, line_start, line_end }`.
- `commit_context` — `{ repo, commit }`.

Agents can interpret this as they like; the only contract is that **analyze(processed_data_path, finding_data)** returns an `AnalysisResult` with `prediction` and `confidence`.

## Requirements

- Python 3.10+
- Docker and Docker Compose
- Dependencies for the evaluation runner: `pip install -r requirements.txt` (Celery, pandas, docker, psutil, requests). Each agent has its own `requirements.txt` in `agents/<agent>/` for its container.

## How to start

1. **Clone or enter the repo** and create a virtual environment (recommended):

   ```bash
   cd sastbench
   python3 -m venv .venv
   source .venv/bin/activate   # Windows: .venv\Scripts\activate
   ```

2. **Install dependencies** (for the evaluation CLI and workers; agents have their own in each `agents/<name>/`):

   ```bash
   pip install -r requirements.txt
   ```

3. **Ensure Docker is installed and running** — the evaluator starts agent containers via Docker Compose.

4. **Run an evaluation** — from the repo root, either use the script:

   ```bash
   ./quickrun.sh
   ```

   or run the CLI yourself (e.g. with agent-specific options):

   ```bash
   cd evaluation
   python evaluation_cli.py run \
     --agent-dir ../agents/simple_react_agent \
     --dataset ../data/sastbench-v0.1-jan2024-jun2024.json \
     --output results.json \
     --api-key /path/to/your-credentials.json
   ```

   Results are written to the path given by `--output`; logs go to `logs/` when using `quickrun.sh`.

## Quick start

From the repo root, after following [How to start](#how-to-start), run:

```bash
./quickrun.sh
```

To pass agent-specific options (e.g. API key and model), add them after the script:

```bash
./quickrun.sh --api-key /path/to/gcp-credentials.json --model vertex_ai/gemini-1.5-flash
```

Show all arguments for an agent:

```bash
cd evaluation && python evaluation_cli.py run --agent-dir ../agents/simple_react_agent --show-analyzer-args
```

## Commands

- **`run`** — Run the evaluation (required: `--agent-dir`, `--dataset`; optional: `--output`, `--workers`, and schema-based args).
- **`clean`** — Clear caches: `--repos`, `--processed`, or `--all`.

## Adding an agent

The evaluator treats every agent the same: it runs a Docker service that exposes `/health`, `/preprocess`, and `/analyze`, and it passes whatever is in each finding’s `to_analyzer` field into `analyze`. The interface is **generic** — your agent can expect any JSON shape in `finding_data` as long as your dataset supplies it in `to_analyzer` and you return an `AnalysisResult` with `prediction` and `confidence`.

**Recommended way to add an agent:** copy an existing one and adapt it.

**What usually stays the same:** The **docker-compose** setup and the **preprocess** step are typically left as-is (or with minimal changes). All bundled agents use the same pattern: preprocess copies the repository into `output_path/source_files` so the container has the code at the right commit; the compose file just builds the image and mounts your code and the shared `analyzer_interface`. You only need to change these if your agent needs extra services, different env vars, or a different way to prepare the repo.

**What you change:** The **analyze** logic is where agents differ. You implement (or replace) the `analyze(processed_data_path, finding_data)` method in `analyzer.py`: it receives the preprocessed data and one finding’s `to_analyzer` payload and returns an `AnalysisResult`. That’s the part that defines your agent’s behavior (e.g. ReAct vs single-shot LLM vs tool-using agent). You may also add or adjust arguments in `agent_schema.json` if your analyzer needs new options (model, API key, etc.).

1. Copy an existing agent directory under `agents/` (e.g. `cp -r agents/simple_react_agent agents/my_agent`).
2. Implement or change the **analyze** logic in `analyzer.py`. Keep **preprocess** and **docker-compose.yml** unless you have a reason to do otherwise. The base class is in `agents/analyzer_interface.py`: implement `preprocess(repo_path, output_path)` and `analyze(processed_data_path, finding_data)`.
3. Adjust `agent_schema.json` to declare any CLI arguments your agent needs (API keys, model name, etc.). The evaluator reads this and adds matching `--...` options; their values are written into a config and passed into the container.
4. Keep `docker-compose.yml` and `Dockerfile` so the service still mounts your code and `../analyzer_interface.py`. Update `requirements.txt` if you add dependencies.

Required pieces in the new directory:

- **`analyzer.py`** — Your analyzer class (subclass of `BaseAnalyzer` from `analyzer_interface`): `preprocess` runs once per commit; `analyze` receives `finding_data` (the `to_analyzer` object) and returns `AnalysisResult(prediction=..., confidence=...)`.
- **`app.py`** — Flask app that exposes `/health`, `/preprocess`, `/analyze` and delegates to your analyzer.
- **`docker-compose.yml`** — Defines the `analyzer` service and mounts `./analyzer.py`, `./app.py`, and `../analyzer_interface.py`.
- **`agent_schema.json`** — JSON object with an `"arguments"` array describing each CLI argument (name, type, help, required, default, choices). The evaluator uses this to build the run command and to generate the config file for the container.
- **`Dockerfile`** and **`requirements.txt`** — As needed for your runtime.

The evaluator discovers the agent via `--agent-dir` and uses `agent_schema.json` to build the run command and config for the container. No changes to the evaluation CLI are required when you add a new agent.


## How to Cite?
```bibtex
@article{feiglin2026sastbench,
  title={SastBench: A Benchmark for Testing Agentic SAST Triage},
  author={Feiglin, Jake and Dar, Guy},
  journal={arXiv preprint arXiv:2601.02941},
  year={2026}
}
```
