# Replication package

**Fixing, Breaking, or Faking It? An Execution-Calibrated Evaluation of LLM Vulnerability Patching in JavaScript, Python, Go, and Java, and the Limits of LLM-as-Judge**

Patrick Deininger<sup>1,2</sup> and Wolfgang Slany<sup>1</sup>
<sup>1</sup> Institute of Software Engineering and AI, Graz University of Technology
<sup>2</sup> Institute of Computer Science and AI, FH JOANNEUM

Submitted to *Journal of Cybersecurity and Privacy* (MDPI). Revised version, round 1.
Archive DOI: <https://doi.org/10.5281/zenodo.21645414> · Licence: CC BY 4.0

---

## What this package is

The study asks whether LLM-proposed security patches actually remove the vulnerability
*without breaking working code*, and whether an LLM judge can measure that. It scores
patches on two axes, **neutralisation** (the vulnerability is gone) and **functional
preservation** (nothing else broke), using a real **execution oracle** as the reference
criterion and an LLM-as-judge as the scalable proxy. The oracle is a strong but imperfect
criterion, not absolute ground truth, and the paper quantifies its limits.

The headline result is about the instrument: two cross-family judges agree far more with
*each other* (functional Cohen's kappa = 0.75) than either agrees with execution
(kappa <= 0.26). **Judge-judge agreement is reliability, not validity.** Under the
vulnerability-clustered bootstrap introduced in this revision the separation is unchanged
and the intervals do not overlap: judge-judge [0.57, 0.89] against judge-execution
[0.14, 0.42] and [0.08, 0.35].

This archive contains everything needed to re-derive every number, figure and table in
Section 4 of the paper from the raw per-attempt records, without spending a cent on API
calls.

## Contents

```
harness/          evaluation harness (providers, judge, execution oracle, store, CLI)
  oracle/         dual-criterion execution oracle + language backends
  oracle/examples/  the executable benchmark: js/py/go benchmark cases
  oracle/adapters/  Vul4J (real Java CVE) adapter
scripts/          analysis + figure generation (see "Reproducing" below)
tests/            unit + integration test suite
config/           model roster, provider routing, July-2026 price constants
results/          raw per-attempt SQLite databases (the evidence base)
requirements.txt  Python dependencies
README.md         this file
```

Not included, by design: the third-party corpora (see *Obtaining the datasets*) and any
API credentials.

## The result databases

Every figure and table in the paper is computed from these. They are the archive's core.

| File | Contents | Used for |
|---|---|---|
| `tier1_js_v1.sqlite` | 922 JavaScript patches, 8 models, both judges | RQ1, RQ4; Figures 1 and 4; Tables 2 and 6 |
| `tier2_multi.sqlite` | 144 executable patches (JS + Python), both judges | RQ2, RQ3; Figures 2 and 3; Tables 3, 4 and 5 |
| `tier2_new.sqlite` | 128 executable patches incl. Go, both judges | three-language robustness check |
| `tier2_vul4j_full.sqlite` | 254 scored patches over 33 real Java CVEs, both judges | Section 4.5 (repository-scale) |
| `tier2_vul4j.sqlite` | 21-patch Java pilot | superseded by the above; retained for provenance |

Each attempt row records the prompt, the generated patch, token counts, latency, the
execution outcome (`CORRECT` / `OVERFIX` / `INEFFECTIVE` / `ERROR`), and one judgement row
per judge model (`judge_model` distinguishes `claude-haiku` from `gpt-frontier`).

> **Note on cost columns.** The `cost_usd` column stores the run-time value at the moment
> of the call and is superseded. The paper's Table 2 recomputes cost from the stored token
> counts times the July-2026 price constants shipped in `config/models.yaml`, so the
> figures stay reproducible as list prices change.

> **Note on missing usage data.** The OpenRouter API did not return a usage block for some
> calls: 28 of 115 Qwen attempts in `tier1_js_v1.sqlite`, 4 of 18 in `tier2_multi.sqlite`,
> 6 of 32 in `tier2_new.sqlite`, and 30 of 31 Qwen plus 1 Llama attempt in
> `tier2_vul4j_full.sqlite`. Those attempts returned a patch and are scored normally, so no
> correctness, kappa or over-fix figure is affected; they carry zero tokens, so cost for the
> affected model is averaged over the attempts that did report usage.
> `scripts/token_distributions.py` reports the counts and the effect.

## Setup

```bash
python -m pip install -r requirements.txt
```

Python 3.11 was used for all reported runs.

API keys are needed **only** to generate new patches or run new judgements. Every number in
the paper can be re-derived from the shipped databases with no keys and no network access.
If you do want to run new model calls:

```bash
cp .env.example .env     # then paste your own keys
```

`.env` is deliberately absent from this archive and is git-ignored upstream.

## Reproducing the paper (no API keys, no network)

All commands below read only the shipped databases. Each was run immediately before this
archive was built; the values shown are what they print.

```bash
# Figures 1-4 -> figures/*.pdf
python scripts/make_paper_figures.py
#   -> Tier-1 n=915, Tier-2 multi-lang n=144

# Tier-1 commercial-over-open gap with the CVE-clustered bootstrap CI
python scripts/tier1_class_ci.py
#   -> commercial 0.1848, open 0.0923, difference 0.0925
#      CVE-clustered 95% CI [0.044, 0.148]   <- the CI reported in the paper

# The model-level (4-vs-4) contrast the design invites
python scripts/model_level_test.py
#   -> Tier-1 Welch t = 3.12, Mann-Whitney U = 15/16

# Real-Java execution corpus
python scripts/vul4j_stats.py
#   -> 254 scored attempts, 33 CVEs, 23 CORRECT = 0.091 [0.061, 0.132]

# Second-judge rankings, PABAK, bootstrap CIs for the headline kappas
python scripts/revision_stats.py
```

Four scripts were added for the round-1 revision, each answering a specific reviewer
request:

```bash
# Reviewer 1.1: sensitivity to unequal per-model coverage
python scripts/common_subset_sensitivity.py
#   -> 108 functions common to all 8 models (864 attempts)
#      ranking preserved, Spearman rho = 0.994
#      class gap 0.0925 (full) vs 0.0926 (common subset)

# Reviewer 1.2: vulnerability-clustered CIs for every kappa in Table 5
python scripts/clustered_kappa.py
#   -> functional axis: Haiku 0.262 [0.143, 0.416], GPT-5.2 0.185 [0.077, 0.345],
#      judge-judge 0.751 [0.574, 0.889]  (intervals do not overlap)

# Reviewer 1.3: common-denominator comparison and confusion matrices
python scripts/overfix_confusion.py
#   -> on the 112 execution-neutralising patches: execution 8, Haiku 17, GPT-5.2 27

# Reviewer 2.7: input vs output token distributions behind the cost table
python scripts/token_distributions.py
#   -> GPT-5-mini output mean 1403 tokens vs 453 for GPT-5.2 (reasoning tokens)
```

`scripts/prompt_variant_judge.py` is the prompt-sensitivity robustness check. It is the one
analysis that **requires live API access**: it re-judges the 144 benchmark patches with a
structurally different prompt and its verdicts were not persisted to a database. Its result
is reported in the paper and flagged there as offline-non-reproducible.

## Tests

```bash
python -m pytest -q
# 51 passed, 4 skipped
```

That is the expected result **from this archive**, verified by extracting it into a clean
directory with no API keys in the environment. Four tests skip by design: one needs Docker,
and three need the third-party corpora that this archive does not redistribute. Once those
datasets are in place (see *Obtaining the datasets*) the suite reports 54 passed, 1 skipped.

## Obtaining the datasets

This archive does not redistribute third-party corpora. Fetch them from their original
sources and place them as follows.

| Corpus | Source | Expected path |
|---|---|---|
| **CleanVul** — Tier-1 JavaScript corpus | Li, Y.; Zhang, T.; Widyasari, R.; et al. *CleanVul*, arXiv:2411.17274. Released by the authors on Hugging Face. | `data/cleanvul/vulnerability_score_4.csv` |
| **Vul4J** — real Java CVEs | Bui, Q.C.; Scandariato, R.; Díaz Ferreyra, N. *Vul4J*, MSR 2022, doi:10.1145/3524842.3528482. Execution uses the published Docker image `tuhhsoftsec/vul4j`, which ships the dataset CSV at `/vul4j/dataset/vul4j_dataset.csv`. | Docker image; no local copy needed |
| **PatchEval** — loader only | Wei, Z.; Zeng, J.; Wen, M.; et al. *PatchEval*, arXiv:2511.11019. | `data/patcheval/patcheval_dataset.jsonl` |

Please cite the original dataset papers if you use them, and check each dataset's own
licence before redistributing it.

> PatchEval is supported by a loader but was **not** executed in this study: the public
> release contains no proof-of-concept or test rows, so its sandboxes cannot be run. It is
> judge-only here.

## Running new evaluations

```bash
# Tier-1: broad, judge-scored
python -m harness.cli run-tier1 --source cleanvul --run-id my_run

# Tier-2: executable benchmark with the dual execution oracle
python -m harness.cli tier2-validate --suite all --models <csv> --run-id my_run

# Add a second judge over an existing run
python -m harness.cli judge --db results/my_run.sqlite --run-id my_run \
                           --judge-model gpt-frontier

# Real Java CVEs (resumable; safe to kill and restart)
python scripts/run_vul4j.py --db results/my_vul4j.sqlite --run-id my_vul4j
```

`scripts/run_vul4j.py` is resumable by design: the unit of work is one (vulnerability,
model) pair and a row is written only on completion, so an interrupted run leaves no
partial state and re-running the same command skips finished pairs. This matters because a
full sweep is 8 models over dozens of CVEs at roughly 30 s to 5 min of Maven build each.

## Model configuration and generation parameters

`config/models.yaml` is the frozen record of the evaluated configuration. All eight model
identifiers were re-verified against the live provider model listings on 12 August 2026.
Price sources and dates are recorded per model. Generation parameters are documented in the
file: temperature 0 was requested for every model, but the three commercial reasoning models
(Opus 4.8, GPT-5.2, GPT-5-mini) reject a non-default temperature and run at the provider
default, so sampling temperature covaries with the commercial/open split and the paper
reports it as a confound; `max_tokens` was 8000 for Tier-1 and the benchmark and 16000 for
the Java runs; sampling is single-shot.

Where a vendor does not publish a knowledge cutoff, `training_cutoff` is `null` and the file
says so rather than carrying an estimate. That field feeds only the pre/post-cutoff
contamination split, which the paper reports as unanswerable on this corpus, so no figure or
statistic depends on it.

## Known constraints

- **Long jobs may be killed** by constrained environments. Prefer bounded batches
  (`--max-pairs`, `--max-minutes`) or run the Vul4J sweep where it will not be interrupted.
- **Open-model prices are representative, not exact.** OpenRouter routes across
  sub-providers; the constants in `config/models.yaml` are dated July 2026.
- **Contamination is not testable here.** The CleanVul corpus predates every evaluated
  model's training cutoff, so a pre/post split is not possible. The paper reports
  memorisation as an acknowledged confound rather than a measured effect.
- **The execution oracle is strong but imperfect.** Benchmark functional tests carry 1-3
  assertions per case; the paper treats execution as a strong convergent criterion, not an
  infallible one, and reports the resulting attenuation explicitly.
- **Some attempts lack provider usage data**, which affects cost only and is documented
  above.
